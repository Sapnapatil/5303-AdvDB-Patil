﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Xml;
using UserInformation.Models;

namespace UserInformation.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Create()
        {
            SetViewData();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(UserModel user)
        {
            try
            {
                string newFileName = "D:\\question1.csv";
                string row = user.FirstName + "," + user.LastName + "," + user.Address
                    + "," + user.City + "," + user.State + ","
                    + user.Zipcode + "," + user.IsActive + Environment.NewLine;
                if (!System.IO.File.Exists(newFileName))
                {
                    row = "FirstName,LastName,Address,City,State,Zip,IsActive" + Environment.NewLine;
                    System.IO.File.WriteAllText(newFileName, row);
                }
                System.IO.File.AppendAllText(newFileName, row);
                ViewBag.SuccessMessage = "Data Inserted In "+newFileName+ "Sucessfully ";
                Response.Write("<script>alert(' Data Inserted Sucessfully.')</script>");
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "'Sorry!\n Insertion Failed'";
                Response.Write("<script>alert('Sorry!\n Insertion Failed')" + ex.Message + "</script>");
            }

            return View();

        }
   

        public ActionResult Question1()
        {
            string link = Server.MapPath("~/question1.csv");
            ConvertCSVtoDataTable(link);
            return View();
        }

        protected void ConvertCSVtoDataTable(string strFilePath)
        {
            DataSet ds = new DataSet("Users");
            DataTable dt = new DataTable("User");
            ds.Tables.Add(dt);
            using (StreamReader sr = new StreamReader(strFilePath))
            {
                string[] headers = sr.ReadLine().Split(',');
                foreach (string header in headers)
                {
                    dt.Columns.Add(header);
                }
                while (!sr.EndOfStream)
                {
                    string[] rows = sr.ReadLine().Split(',');
                    DataRow dr = dt.NewRow();
                    for (int i = 0; i < headers.Length; i++)
                    {
                        dr[i] = rows[i];
                    }
                    dt.Rows.Add(dr);
                }

            }


            GetXMLFILE(ds);

        }

        private void GetXMLFILE(DataSet ds)
        {
            //System.IO.StreamWriter xmlSW = new System.IO.StreamWriter("c:/users/sapna/documents/visual studio 2010/Projects/WebApplication1/WebApplication1/Customers.xml");

           // ds.WriteXml(xmlSW, XmlWriteMode.IgnoreSchema);
            //xmlSW.ToString().Replace("_x0020_", "");
            //xmlSW.Close();
            string xmlDS = ds.GetXml();

            CleanInvalidXmlChars(xmlDS);
        }

        public static string CleanInvalidXmlChars(string text)
        {
            string re = @"[^\x09\x0A\x0D\x20-\xD7FF\xE000-\xFFFD\x10000-x10FFFF]";
            string xyz = Regex.Replace(text, "_x0020_", "");
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(xyz);
           doc.Save("D:/question1.xml");
            return text;


        }

        public ActionResult Question2()
        {
            return View();
        }

        public RedirectResult RedirectToAspx()
        {
            return Redirect("/Question3.aspx");
        }

        public RedirectResult RedirectToAspxQuestionWeb5()
        {
            return Redirect("/Web5.aspx");
        }

        private void SetViewData()
        {
            ViewBag.ErrorMessage = string.Empty;
            ViewBag.SuccessMessage = string.Empty;
        }

      
    }
}